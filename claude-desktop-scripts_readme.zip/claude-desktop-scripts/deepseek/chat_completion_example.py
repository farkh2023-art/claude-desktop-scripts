
prompt = "Explique-moi la relativité restreinte."
response = call_chat_model(prompt)
print(response)

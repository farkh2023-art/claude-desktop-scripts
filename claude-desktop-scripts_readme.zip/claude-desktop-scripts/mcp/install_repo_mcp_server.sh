
#!/bin/bash
npx mcp-server@latest

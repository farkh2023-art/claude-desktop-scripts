
#!/bin/bash
git clone https://github.com/votre-repo/mcp-server.git
cd mcp-server
npm install
npm start
